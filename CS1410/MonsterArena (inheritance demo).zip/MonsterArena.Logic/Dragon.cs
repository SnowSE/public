namespace MonsterArena.Logic;

public class NightFury : Dragon
{
    public NightFury(string name) : base(name, 250)
    { }

    public override string GetBattleCry() => "Screech! I am a NightFury!";

    public virtual bool IsLightFury => false;
}

public class LightFury : NightFury
{
    public LightFury(string name) : base(name)
    {}
    public override bool IsLightFury => true;
}


/// <summary>
/// A powerful dragon that breathes fire!
/// Demonstrates: Overriding abstract AND virtual methods.
/// </summary>
public class Dragon : Monster
{
    private readonly Random _random = new();

    public Dragon(string name) : base(name, maxHealth: 150)
    {
        // Dragons are tough! High health.
    }

    protected Dragon(string name, int maxHealth) : base(name, maxHealth)
    {
    }

    // REQUIRED: Must override abstract method
    public override int Attack()
    {
        // Dragons deal 20-35 fire damage
        return _random.Next(20, 36);
    }

    // REQUIRED: Must override abstract method
    public override string GetBattleCry()
    {
        return "ROOOAAAR! Feel my flames!";
    }

    // OPTIONAL: Override virtual method for custom behavior
    public override int Defend(int incomingDamage)
    {
        // Dragon scales are tough! Only take 50% damage
        return incomingDamage / 2;
    }

    // OPTIONAL: Dragons have a special fire breath ability
    public override string? SpecialAbility()
    {
        return "Fire Breath: Deals 50 damage to all enemies!";
    }
}
