namespace MonsterArena.Logic;

/// <summary>
/// A sneaky goblin that attacks quickly!
/// Demonstrates: Only overriding what's REQUIRED (abstract methods).
/// </summary>
public class Goblin : Monster
{
    private readonly Random _random = new();

    public Goblin(string name) : base(name, maxHealth: 60)
    {
        // Goblins are weak but fast
    }

    // REQUIRED: Must override abstract method
    public override int Attack()
    {
        // Goblins deal 5-15 quick stab damage
        return _random.Next(5, 16);
    }

    // REQUIRED: Must override abstract method
    public override string GetBattleCry()
    {
        return "Hehehe! Stab stab!";
    }

    // NOTE: We do NOT override Defend() or SpecialAbility()
    // The goblin uses the DEFAULT implementation from Monster base class!
    // - Defend: takes 75% damage (default)
    // - SpecialAbility: returns null (no special ability)
}
