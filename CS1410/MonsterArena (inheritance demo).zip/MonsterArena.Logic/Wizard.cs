namespace MonsterArena.Logic;

/// <summary>
/// A powerful wizard that casts spells!
/// Demonstrates: Overriding with different logic, calling base methods.
/// </summary>
public class Wizard : Monster
{
    private readonly Random _random = new();
    private int _mana = 100;

    public int Mana => _mana;

    public Wizard(string name) : base(name, maxHealth: 80)
    {
        // Wizards have moderate health but powerful spells
    }

    // REQUIRED: Must override abstract method
    public override int Attack()
    {
        if (_mana >= 10)
        {
            _mana -= 10;
            // Magic missile deals 15-30 damage
            return _random.Next(15, 31);
        }
        // Out of mana! Weak staff bonk
        return _random.Next(1, 5);
    }

    // REQUIRED: Must override abstract method
    public override string GetBattleCry()
    {
        return "By the power of the arcane!";
    }

    // OPTIONAL: Wizards have a magic shield
    public override int Defend(int incomingDamage)
    {
        if (_mana >= 5)
        {
            _mana -= 5;
            // Magic shield blocks 80% of damage!
            return (int)(incomingDamage * 0.2);
        }
        // No mana - use default defense
        return base.Defend(incomingDamage);  // <-- Calling base class method!
    }

    // OPTIONAL: Wizard can cast healing spell
    public override string? SpecialAbility()
    {
        return "Healing Light: Restore 30 HP (costs 20 mana)";
    }

    public void FireStorm(Monster[] targets)
    {
        if (_mana >= 20)
        {
            _mana -= 20;
            foreach (var target in targets)
            {                
                target.TakeDamage(_random.Next(10, 21));
            }
        }
    }

    // Wizard-specific method (not in base class)
    public void RestoreMana(int amount)
    {
        _mana = Math.Min(100, _mana + amount);
    }
}
