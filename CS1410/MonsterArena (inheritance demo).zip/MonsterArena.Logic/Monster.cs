namespace MonsterArena.Logic;

/// <summary>
/// Abstract base class for all monsters in the arena.
/// Students: Notice you CANNOT create an instance of this class directly!
/// </summary>
public abstract class Monster
{
    public string Name { get; protected set; }
    public int Health { get; protected set; }
    public int MaxHealth { get; protected set; }
    public bool IsAlive => Health > 0;

    protected Monster(string name, int maxHealth)
    {
        Name = name;
        MaxHealth = maxHealth;
        Health = maxHealth;
    }

    // ========================================
    // ABSTRACT METHODS - Must be overridden!
    // ========================================

    /// <summary>
    /// Calculate damage dealt to an opponent.
    /// Each monster type calculates damage differently.
    /// </summary>
    public abstract int Attack();

    /// <summary>
    /// Get the monster's battle cry.
    /// Each monster has a unique cry!
    /// </summary>
    public abstract string GetBattleCry();

    // ========================================
    // VIRTUAL METHODS - Can be overridden
    // ========================================

    /// <summary>
    /// Calculate damage reduction when defending.
    /// Default: reduce damage by 25%. Override for custom behavior.
    /// </summary>
    public virtual int Defend(int incomingDamage)
    {
        return (int)(incomingDamage * 0.75);
    }

    /// <summary>
    /// Special ability - not all monsters have one!
    /// Default: returns null (no special ability).
    /// </summary>
    public virtual string? SpecialAbility()
    {
        return null;
    }

    

    // ========================================
    // CONCRETE METHODS - Same for all monsters
    // ========================================

    /// <summary>
    /// Take damage and reduce health.
    /// </summary>
    public void TakeDamage(int damage)
    {
        Health = Math.Max(0, Health - damage);
    }

    /// <summary>
    /// Heal the monster (cannot exceed max health).
    /// </summary>
    public void Heal(int amount)
    {
        Health = Math.Min(MaxHealth, Health + amount);
    }

    /// <summary>
    /// Get a status summary of the monster.
    /// </summary>
    public override string ToString()
    {
        return $"{Name} ({GetType().Name}) - HP: {Health}/{MaxHealth}";
    }
}
