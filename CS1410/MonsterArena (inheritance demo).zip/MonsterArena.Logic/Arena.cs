namespace MonsterArena.Logic;

/// <summary>
/// The battle arena where monsters fight!
/// Demonstrates: Polymorphism - treating different monster types uniformly.
/// </summary>
public class Arena
{
    public List<Monster> Fighters { get; } = new();
    public List<string> BattleLog { get; } = new();

    /// <summary>
    /// Add a monster to the arena.
    /// Notice: We accept any Monster type! Polymorphism in action.
    /// </summary>
    public void AddFighter(Monster monster)
    {
        Fighters.Add(monster);
        LogEvent($"{monster.Name} the {monster.GetType().Name} enters the arena!");
        LogEvent($"  Battle cry: \"{monster.GetBattleCry()}\"");
    }

    /// <summary>
    /// Have one monster attack another.
    /// Shows polymorphism: we don't need to know the specific type!
    /// </summary>
    public int PerformAttack(Monster attacker, Monster defender, bool defenderBlocks = false)
    {
        int damage = attacker.Attack();
        LogEvent($"{attacker.Name} attacks for {damage} damage!");

        if (defenderBlocks)
        {
            damage = defender.Defend(damage);
            LogEvent($"  {defender.Name} blocks! Reduced to {damage} damage.");
        }

        defender.TakeDamage(damage);
        LogEvent($"  {defender.Name} takes {damage} damage. HP: {defender.Health}/{defender.MaxHealth}");

        if (!defender.IsAlive)
        {
            LogEvent($"  {defender.Name} has been defeated!");
        }

        return damage;
    }

    /// <summary>
    /// Show all fighters and their status.
    /// </summary>
    public List<string> GetArenaStatus()
    {
        var status = new List<string> { "=== ARENA STATUS ===" };
        foreach (var fighter in Fighters)
        {
            string alive = fighter.IsAlive ? "READY" : "DEFEATED";
            status.Add($"  [{alive}] {fighter}");

            var special = fighter.SpecialAbility();
            if (special != null)
            {
                status.Add($"         Special: {special}");
            }
        }
        return status;
    }

    private void LogEvent(string message)
    {
        BattleLog.Add(message);
    }
}
