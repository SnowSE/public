using MonsterArena.Logic;
using Xunit;

namespace MonsterArena.Tests;

/// <summary>
/// Tests for the Arena class demonstrating polymorphism.
/// </summary>
public class ArenaTests
{
    [Fact]
    public void ArenaCanHoldDifferentMonsterTypes()
    {
        var arena = new Arena();

        arena.AddFighter(new Dragon("Smaug"));
        arena.AddFighter(new Goblin("Sneaky"));
        arena.AddFighter(new Wizard("Gandalf"));

        Assert.Equal(3, arena.Fighters.Count);
    }

    [Fact]
    public void AttackDealsDamageToDefender()
    {
        var arena = new Arena();
        var dragon = new Dragon("Attacker");
        var goblin = new Goblin("Defender");

        arena.AddFighter(dragon);
        arena.AddFighter(goblin);
        int startHealth = goblin.Health;

        arena.PerformAttack(dragon, goblin);

        Assert.True(goblin.Health < startHealth);
    }

    [Fact]
    public void BlockingReducesDamage()
    {
        var arena = new Arena();
        var goblin = new Goblin("Attacker");
        var dragon = new Dragon("Defender");

        arena.AddFighter(goblin);
        arena.AddFighter(dragon);

        // Dragon with blocking should take less damage
        int damageWithBlock = arena.PerformAttack(goblin, dragon, defenderBlocks: true);

        // Damage was reduced by dragon's Defend (50%)
        Assert.True(damageWithBlock <= 8); // Max goblin damage 15, reduced to 7-8
    }

    [Fact]
    public void BattleLogRecordsEvents()
    {
        var arena = new Arena();
        var dragon = new Dragon("Smaug");

        arena.AddFighter(dragon);

        Assert.Contains(arena.BattleLog, log => log.Contains("Smaug"));
        Assert.Contains(arena.BattleLog, log => log.Contains("ROOOAAAR"));
    }
}
