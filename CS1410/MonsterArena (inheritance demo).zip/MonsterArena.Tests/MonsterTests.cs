using MonsterArena.Logic;
using Shouldly;
using Xunit;

namespace MonsterArena.Tests;

/// <summary>
/// Unit tests demonstrating inheritance behavior.
/// Each test shows a specific OOP concept!
/// </summary>
public class MonsterTests
{
    // ============================================
    // TEST 1: Cannot instantiate abstract class
    // ============================================
    // [Fact]
    // public void CannotCreateAbstractMonster()
    // {
    //     var monster = new Monster("Test", 100);  // COMPILE ERROR!
    // }

    // ============================================
    // TEST 2: Can create concrete derived classes
    // ============================================
    [Fact]
    public void CanCreateDragon()
    {
        var dragon = new Dragon("Smaug");

        Assert.Equal("Smaug", dragon.Name);
        Assert.Equal(150, dragon.MaxHealth);
        Assert.True(dragon.IsAlive);
    }

    [Fact]
    public void CanCreateGoblin()
    {
        var goblin = new Goblin("Sneaky Pete");

        Assert.Equal("Sneaky Pete", goblin.Name);
        Assert.Equal(60, goblin.MaxHealth);
    }

    [Fact]
    public void GetBattleCryChanges()
    {
        var toothless = new NightFury("Toothless");
        Assert.Equal("Screech! I am a NightFury!", toothless.GetBattleCry());
        
        var smaug = new Dragon("Smaug");
        Assert.Equal("ROOOAAAR! Feel my flames!", smaug.GetBattleCry());

        var goblin = new Goblin("Gob");
        Assert.Equal("Hehehe! Stab stab!", goblin.GetBattleCry());
    }

    [Fact]
    public void CanCreateWizard()
    {
        var wizard = new Wizard("Gandalf");

        Assert.Equal("Gandalf", wizard.Name);
        Assert.Equal(80, wizard.MaxHealth);
        Assert.Equal(100, wizard.Mana);  // Wizard-specific property
    }

    // ============================================
    // TEST 3: Abstract methods are overridden
    // ============================================
    [Fact]
    public void EachMonsterHasUniqueBattleCry()
    {
        var dragon = new Dragon("Draco");
        var goblin = new Goblin("Gob");
        var wizard = new Wizard("Merlin");

        // Each override returns different text
        Assert.Contains("ROOOAAAR", dragon.GetBattleCry());
        Assert.Contains("Stab", goblin.GetBattleCry());
        Assert.Contains("arcane", wizard.GetBattleCry());
    }

    [Fact]
    public void AttackReturnsDamageInExpectedRange()
    {
        var dragon = new Dragon("Test Dragon");

        // Run multiple times to verify range
        for (int i = 0; i < 100; i++)
        {
            int damage = dragon.Attack();
            Assert.InRange(damage, 20, 35);
        }
    }

    // ============================================
    // TEST 4: Virtual method - default vs override
    // ============================================
    [Fact]
    public void GoblinUsesDefaultDefend()
    {
        var goblin = new Goblin("Test Goblin");

        // Default: 75% of incoming damage
        int reduced = goblin.Defend(100);

        Assert.Equal(75, reduced);  // 100 * 0.75 = 75
    }

    [Fact]
    public void DragonOverridesDefendWithBetterArmor()
    {
        var dragon = new Dragon("Test Dragon");

        // Dragon override: 50% of incoming damage
        int reduced = dragon.Defend(100);

        Assert.Equal(50, reduced);  // 100 / 2 = 50
    }

    [Fact]
    public void WizardDefendUsesBaseWhenOutOfMana()
    {
        var wizard = new Wizard("Test Wizard");

        // Drain the wizard's mana
        while (wizard.Mana >= 5)
        {
            wizard.Defend(10);
        }

        // Now should use base.Defend() - 75% damage
        int reduced = wizard.Defend(100);

        Assert.Equal(75, reduced);
    }

    // ============================================
    // TEST 5: Virtual method - SpecialAbility
    // ============================================
    [Fact]
    public void GoblinHasNoSpecialAbility()
    {
        var goblin = new Goblin("Test Goblin");

        // Uses default: returns null
        Assert.Null(goblin.SpecialAbility());
    }

    [Fact]
    public void DragonHasFireBreath()
    {
        var dragon = new Dragon("Test Dragon");

        var ability = dragon.SpecialAbility();

        Assert.NotNull(ability);
        Assert.Contains("Fire Breath", ability);
    }

    // ============================================
    // TEST 6: Polymorphism - treat all as Monster
    // ============================================
    [Fact]
    public void PolymorphismAllMonstersCanAttack()
    {
        // Create a list of the BASE type
        List<Monster> monsters = new()
        {
            new Dragon("Draco"),
            new Goblin("Gob"),
            new Wizard("Wiz"),
            new NightFury("Toothless"),
            new LightFury("Nameless")
        };

        // Call Attack() on each - polymorphism picks the right override!
        foreach (Monster monster in monsters)
        {
            int damage = monster.Attack();
            Assert.True(damage > 0);
        }
    }

    // ============================================
    // TEST 7: Concrete base class methods work
    // ============================================
    [Fact]
    public void TakeDamageReducesHealth()
    {
        var goblin = new Goblin("Test");
        int startHealth = goblin.Health;

        goblin.TakeDamage(20);

        Assert.Equal(startHealth - 20, goblin.Health);
    }

    [Fact]
    public void HealthCannotGoBelowZero()
    {
        var goblin = new Goblin("Test");

        goblin.TakeDamage(1000);

        Assert.Equal(0, goblin.Health);
        Assert.False(goblin.IsAlive);
    }

    [Fact]
    public void HealCannotExceedMaxHealth()
    {
        var dragon = new Dragon("Test");
        dragon.TakeDamage(50);

        dragon.Heal(1000);

        Assert.Equal(dragon.MaxHealth, dragon.Health);
    }

    [Fact]
    public void FireStormDealsDamageToAllTargets()
    {
        var wizard = new Wizard("Test Wizard");
        var goblin = new Goblin("Target Goblin");
        var dragon = new Dragon("Target Dragon");
        var toothless = new NightFury("Toothless");

        var targets = new Monster[] { goblin, dragon };

        wizard.FireStorm(targets);

        Assert.True(goblin.Health < goblin.MaxHealth);
        Assert.True(dragon.Health < dragon.MaxHealth);
        Assert.True(toothless.Health == toothless.MaxHealth);
    }
}
